# Importar Flask y módulos necesarios
from flask import Flask, render_template, request, redirect
from flask_sqlalchemy import SQLAlchemy

app = Flask(__name__)

# Configurar la base de datos (SQLite)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///feedback.db'  # Archivo de base de datos local
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

# Crear una instancia de la base de datos
db = SQLAlchemy(app)

# Modelo para almacenar los datos del formulario
class Feedback(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    email = db.Column(db.String(120), nullable=False)
    text = db.Column(db.Text, nullable=False)

# Crear las tablas de la base de datos
with app.app_context():
    db.create_all()

@app.route('/', methods=['GET', 'POST'])
def index():
    return render_template('index.html')

@app.route('/feedback', methods=['POST'])
def feedback():
    email = request.form['email']  # Extrae el valor del campo 'email' del formulario
    text = request.form['text']    # Extrae el valor del campo 'text' del formulario

    # Crear una nueva entrada en la base de datos
    nuevo_feedback = Feedback(email=email, text=text)
    db.session.add(nuevo_feedback)
    db.session.commit()

    print(f"Feedback recibido de {email}: {text}")

    return redirect('/')

# Ejecutar la aplicación
if __name__ == "__main__":
    app.run(debug=True)